<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'pet shop';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Обробка відправленої форми
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $search_term = $_POST['search_term'];

    // SQL-запит для пошуку продуктів за назвою або категорією
    $sql = "SELECT * FROM product WHERE product_name LIKE '%$search_term%' OR category LIKE '%$search_term%'";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Вивід результатів пошуку
        echo '<table border="1">';
        echo '<tr><th>ID</th><th>Назва продукту</th><th>Кількість</th><th>Ціна</th><th>Категорія</th></tr>';

        while ($row = $result->fetch_assoc()) {
            echo '<tr>';
            echo '<td>' . $row['product_id'] . '</td>';
            echo '<td>' . $row['product_name'] . '</td>';
            echo '<td>' . $row['Amount'] . '</td>';
            echo '<td>' . $row['price'] . '</td>';
            echo '<td>' . $row['category'] . '</td>';
            echo '</tr>';
        }

        echo '</table>';
    } else {
        echo "Немає результатів для відображення.";
    }
}

$conn->close();
?>


<form method="post" action="">
    <label for="search_term">Пошук за назвою, категорією, id:</label>
    <input type="text" name="search_term" required>
    <input type="submit" value="Пошук">
</form>

<br><br>

    <ul>
        <li><a href="showProduct.php">Таблиця Employee </a><br></li>
        <li><a href="index.html">На головну</a><br></li>
    </ul>