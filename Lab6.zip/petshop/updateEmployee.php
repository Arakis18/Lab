<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'pet shop';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the form is submitted for employee selection
    if (isset($_POST['employee_id'])) {
        // Form for selecting employee for update
        $employee_id = $_POST['employee_id'];

        // Fetch the employee details for the selected employee
        $select_query = "SELECT * FROM employee WHERE employee_id = $employee_id";
        $result = $conn->query($select_query);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();

            // Display a form with the current details to allow for modification
            echo '<form method="post" action="">';
            echo '<input type="hidden" name="employee_id" value="' . $row['employee_id'] . '">';
            echo '<label for="name">Ім\'я:</label>';
            echo '<input type="text" name="name" value="' . $row['Name'] . '" required><br>';

            echo '<label for="surname">Прізвище:</label>';
            echo '<input type="text" name="surname" value="' . $row['Surname'] . '" required><br>';

            echo '<label for="phone_number">Номер телефону:</label>';
            echo '<input type="text" name="phone_number" value="' . $row['phone_number'] . '" required><br>';

            echo '<input type="submit" value="Змінити працівника">';
            echo '</form>';
        } else {
            echo "Немає даних для зміни.";
        }
    } elseif (isset($_POST['update_employee'])) {
        // Form submitted for updating employee details
        $employee_id = $_POST['employee_id'];
        $name = $_POST['name'];
        $surname = $_POST['surname'];
        $phone_number = $_POST['phone_number'];

        // Update the employee details
        $update_query = "UPDATE employee SET Name='$name', Surname='$surname', phone_number='$phone_number' WHERE employee_id=$employee_id";

        if ($conn->query($update_query) === TRUE) {
            echo "Інформацію про працівника успішно оновлено!";
        } else {
            echo "Помилка при оновленні інформації про працівника: " . $conn->error;
        }
    }
}

// Display a list of employees for selection
$select_query = "SELECT * FROM employee";
$result = $conn->query($select_query);

if ($result->num_rows > 0) {
    echo '<form method="post" action="">';
    echo '<label for="employee_id">Виберіть працівника для зміни:</label>';
    echo '<select name="employee_id">';
    while ($row = $result->fetch_assoc()) {
        echo '<option value="' . $row['employee_id'] . '">' . $row['Name'] . ' ' . $row['Surname'] . '</option>';
    }
    echo '</select>';
    echo '<input type="submit" name="update_employee" value="Змінити">';
    echo '</form>';
} else {
    echo "Немає даних для зміни.";
}

$conn->close();
?>
<br><br>

<ul>
        <li><a href="showEmployee.php">Таблиця Empolyee</a><br></li>
        <li><a href="index.html">На головну</a><br></li>
</ul>
