<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'pet shop';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to select existing employee information
$select_query = "SELECT * FROM employee";
$result = $conn->query($select_query);

if ($result->num_rows > 0) {
    // Display table with employees
    echo '<table border="1">';
    echo '<tr><th>ІД працівника</th><th>Ім\'я працівника</th><th>Прізвище працівника</th><th>Номер телефону</th></tr>';

    while ($row = $result->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . $row['employee_id'] . '</td>';
        echo '<td>' . $row['Name'] . '</td>';
        echo '<td>' . $row['Surname'] . '</td>';
        echo '<td>' . $row['phone_number'] . '</td>';
        echo '</tr>';
    }

    echo '</table>';
} else {
    echo "Немає даних для відображення.";
}

// Handling the submitted form for employee deletion
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $employee_id = $_POST['employee_id'];

    // SQL query for deleting an employee
    $sql = "DELETE FROM employee WHERE employee_id='$employee_id'";

    if ($conn->query($sql) === TRUE) {
        echo "Працівника успішно видалено!";
    } else {
        echo "Помилка видалення працівника: " . $conn->error;
    }
}

// Query to select existing employee information after deletion
$select_query = "SELECT * FROM employee";
$result = $conn->query($select_query);

if ($result->num_rows > 0) {
    // Display the form for employee deletion
    echo '<form method="post" action="">';
    echo '<label for="employee_id">Виберіть працівника для видалення:</label>';
    echo '<select name="employee_id">';

    while ($row = $result->fetch_assoc()) {
        echo '<option value="' . $row['employee_id'] . '">' . $row['Name'] . ' ' . $row['Surname'] . '</option>';
    }

    echo '</select>';
    echo '<input type="submit" value="Видалити">';
    echo '</form>';
} else {
    echo "Немає даних для видалення.";
}

$conn->close();
?>
<br><br> 

<ul>
    <li><a href="showEmployee.php">Таблиця Employee </a><br></li>
    <li><a href="index.html">На головну</a><br></li>
</ul>
