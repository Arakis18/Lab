<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'pet shop';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to select existing customer information
$select_query = "SELECT * FROM customer";
$result = $conn->query($select_query);

if ($result->num_rows > 0) {
    // Display table with customers
    echo '<table border="1">';
    echo '<tr><th>ІД клієнта</th><th>Ім\'я клієнта</th><th>Прізвище клієнта</th><th>Номер телефону</th></tr>';

    while ($row = $result->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . $row['customer_id'] . '</td>';
        echo '<td>' . $row['Name'] . '</td>';
        echo '<td>' . $row['Surname'] . '</td>';
        echo '<td>' . $row['phone_number'] . '</td>';
        echo '</tr>';
    }

    echo '</table>';
} else {
    echo "Немає даних для відображення.";
}

// Handling the submitted form for customer deletion
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $customer_id = $_POST['customer_id'];

    // SQL query for deleting a customer
    $sql = "DELETE FROM customer WHERE customer_id='$customer_id'";

    if ($conn->query($sql) === TRUE) {
        echo "Клієнта успішно видалено!";
    } else {
        echo "Помилка видалення клієнта: " . $conn->error;
    }
}

// Query to select existing customer information after deletion
$select_query = "SELECT * FROM customer";
$result = $conn->query($select_query);

if ($result->num_rows > 0) {
    // Display the form for customer deletion
    echo '<form method="post" action="">';
    echo '<label for="customer_id">Виберіть клієнта для видалення:</label>';
    echo '<select name="customer_id">';

    while ($row = $result->fetch_assoc()) {
        echo '<option value="' . $row['customer_id'] . '">' . $row['Name'] . ' ' . $row['Surname'] . '</option>';
    }

    echo '</select>';
    echo '<input type="submit" value="Видалити">';
    echo '</form>';
} else {
    echo "Немає даних для видалення.";
}

$conn->close();
?>
<br><br>

<ul>
    <li><a href="showCustomer.php">Таблиця Customer </a><br></li>
    <li><a href="index.html">На головну</a><br></li>
</ul>
