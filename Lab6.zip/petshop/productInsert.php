<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'pet shop';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Обробка відправленої форми
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $product_id = $_POST['product_id'];
    $product_name = $_POST['product_name'];
    $Amount = $_POST['Amount'];
    $price = $_POST['price'];
    $category = $_POST['category'];

    // SQL-запит для вставки нового продукту з вказаними значеннями
    $sql = "INSERT INTO product (product_id, product_name, Amount, price, category) VALUES (?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);

    // Check if the prepared statement was successful
    if ($stmt === false) {
        echo "Error in prepared statement: " . $conn->error;
    } else {
        // Bind parameters and execute the statement
        $stmt->bind_param("isiss", $product_id, $product_name, $Amount, $price, $category);

        if ($stmt->execute() === TRUE) {
            echo "Продукт успішно додано!";
        } else {
            echo "Помилка додавання продукту: " . $stmt->error;
        }

        // Close the prepared statement
        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Форма для додавання продукту</title>
</head>
<body>

    <h2>Додати новий продукт</h2>

    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <label for="product_id">ID продукту (existing in order table):</label>
        <input type="text" name="product_id" required><br>

        <label for="product_name">Назва продукту:</label>
        <input type="text" name="product_name" required><br>

        <label for="Amount">Кількість:</label>
        <input type="number" name="Amount" required><br>

        <label for="price">Ціна:</label>
        <input type="number" name="price" required><br>

        <label for="category">Категорія:</label>
        <input type="text" name="category" required><br>

        <input type="submit" value="Додати продукт">
    </form>
    <br><br><br>

    <ul>
        <li><a href="showProduct.php">Таблиця Product</a><br></li>
        <li><a href="index.html">На головну</a><br></li>
    </ul>
</body>
</html>
