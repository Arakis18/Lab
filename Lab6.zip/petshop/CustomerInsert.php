<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'pet shop';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if there is at least one order in the order table
$orderCheckQuery = "SELECT order_id FROM `order` LIMIT 1";
$orderCheckResult = $conn->query($orderCheckQuery);

if ($orderCheckResult->num_rows === 0) {
    // If no order exists, you might want to handle this case according to your application logic.
    echo "Error: No orders found. Please create an order first.";
} else {
    // Proceed with customer insertion
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $name = $_POST['name'];
        $surname = $_POST['surname'];
        $phone_number = $_POST['phone_number'];

        // Assuming order_id is a valid order_id in the order table
        $order_id = 1;  // Replace with a valid order_id

        $sql = "INSERT INTO customer (Name, Surname, phone_number, order_id) VALUES ('$name', '$surname', '$phone_number', '$order_id')";

        if ($conn->query($sql) === TRUE) {
            echo "Новий клієнт успішно доданий!";
        } else {
            echo "Помилка при додаванні клієнта: " . $conn->error;
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="uk">

<head>
    <meta charset="utf-8">
    <meta name="keywords" content="Лабораторна робота, MySQL, робота з базою даних">
    <meta name="description" content="Лабораторна робота. Робота з базою даних">
    <title>Додавання нового клієнта</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <h1>Таблиця Customers</h1>

    <h2>Додавання нового клієнта</h2>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <label for="name">Ім'я:</label>
        <input type="text" name="name" required><br>

        <label for="surname">Прізвище:</label>
        <input type="text" name="surname" required><br>

        <label for="phone_number">Номер телефону:</label>
        <input type="text" name="phone_number" required><br>

        <input type="submit" value="Додати клієнта">
    </form>

    <br><br>

    <ul>
        <li><a href="showCustomer.php">Таблиця Customer </a><br></li>
        <li><a href="index.html">На головну</a><br></li>
    </ul>

</body>

</html>
