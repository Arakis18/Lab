<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'pet shop';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $phone_number = $_POST['phone_number'];

    $sql = "INSERT INTO employee (Name, Surname, phone_number) VALUES ('$name', '$surname', '$phone_number')";

    if ($conn->query($sql) === TRUE) {
        echo "Новий працівник успішно доданий!";
    } else {
        echo "Помилка при додаванні працівника: " . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="uk">

<head>
    <meta charset="utf-8">
    <meta name="keywords" content="Лабораторна робота, MySQL, робота з базою даних">
    <meta name="description" content="Лабораторна робота. Робота з базою даних">
    <title>Додавання нового працівника</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <h1>Таблиця Employee</h1>

    <!-- Форма додавання нового працівника -->
    <h2>Додавання нового працівника</h2>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <label for="name">Ім'я:</label>
        <input type="text" name="name" required><br>

        <label for="surname">Прізвище:</label>
        <input type="text" name="surname" required><br>

        <label for="phone_number">Номер телефону:</label>
        <input type="text" name="phone_number" required><br>

        <input type="submit" value="Додати працівника">
    </form>

    <br><br>

    <ul>
        <li><a href="showEmployee.php">Таблиця Employee </a><br></li>
        <li><a href="index.html">На головну</a><br></li>
    </ul>

</body>

</html>
