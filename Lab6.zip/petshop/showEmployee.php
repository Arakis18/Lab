<html>
<head>
    <meta charset="utf-8">
    <meta name="keywords" content="Лабораторна робота, MySQL, робота з базою даних">
    <meta name="description" content="Лабораторна робота. Робота з базою даних">
    <title>Таблиця employee</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Таблиця Employee</h1>


    <?php

    include "databaseConnect.php";

    try {
        $stmt = $pdo->query("SELECT * FROM employee");
        // Виконання запиту і отримання результатів
        printf("<h3>Список працівників:</h3>");
        printf("<table><tr><th>ІД працівника</th><th>Ім'я працівника</th><th>Прізвище працівника</th><th>Номер телефону</th></tr>");
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            printf("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>",
        $row['employee_id'], $row['Name'], $row['Surname'], $row['phone_number']);
        };
        printf("</table>");
    } catch (PDOException $e) {
        die("Помилка запиту: " . $e->getMessage());
    }

    ?>

    <br><br><br>

    <ul>
    <li><a href="searchEmployee.php">Пошук працівника</a><br></li>
        <li><a href="EmployeeInsert.php">Вставити рядок</a><br></li>
        <li><a href="updateEmployee.php">Змінити рядок</a><br></li>
        <li><a href="EmployeeDelete.php">Видалити рядок</a><br></li>
        <li><a href="index.html">На головну</a><br></li>
    </ul>
    
</body>
</html>



