<?php
$host = 'localhost';
$dbname = 'pet shop';
$username = 'root';
$password = ''
?>
