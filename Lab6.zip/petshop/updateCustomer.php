<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'pet shop';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    if (isset($_POST['customer_id'])) {
        
        $customer_id = $_POST['customer_id'];

        
        $select_query = "SELECT * FROM customer WHERE customer_id = $customer_id";
        $result = $conn->query($select_query);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();

            
            echo '<form method="post" action="">';
            echo '<input type="hidden" name="customer_id" value="' . $row['customer_id'] . '">';
            echo '<label for="name">Ім\'я:</label>';
            echo '<input type="text" name="name" value="' . $row['Name'] . '" required><br>';

            echo '<label for="surname">Прізвище:</label>';
            echo '<input type="text" name="surname" value="' . $row['Surname'] . '" required><br>';

            echo '<label for="phone_number">Номер телефону:</label>';
            echo '<input type="text" name="phone_number" value="' . $row['phone_number'] . '" required><br>';

            echo '<input type="submit" value="Змінити працівника">';
            echo '</form>';
        } else {
            echo "Немає даних для зміни.";
        }
    } elseif (isset($_POST['update_customer'])) {
       
        $customer_id = $_POST['customer_id'];
        $name = $_POST['name'];
        $surname = $_POST['surname'];
        $phone_number = $_POST['phone_number'];

    
        $update_query = "UPDATE customer SET Name='$name', Surname='$surname', phone_number='$phone_number' WHERE customer_id=$customer_id";

        if ($conn->query($update_query) === TRUE) {
            echo "Інформацію про клієнта успішно оновлено!";
        } else {
            echo "Помилка при оновленні інформації про клієнта: " . $conn->error;
        }
    }
}


$select_query = "SELECT * FROM customer";
$result = $conn->query($select_query);

if ($result->num_rows > 0) {
    echo '<form method="post" action="">';
    echo '<label for="customer_id">Виберіть клієнта для зміни:</label>';
    echo '<select name="customer_id">';
    while ($row = $result->fetch_assoc()) {
        echo '<option value="' . $row['customer_id'] . '">' . $row['Name'] . ' ' . $row['Surname'] . '</option>';
    }
    echo '</select>';
    echo '<input type="submit" name="update_customer" value="Змінити">';
    echo '</form>';
} else {
    echo "Немає даних для зміни.";
}

$conn->close();
?>
<br><br>

<ul>
        <li><a href="showCustomer.php">Таблиця Empolyee</a><br></li>
        <li><a href="index.html">На головну</a><br></li>
</ul>
