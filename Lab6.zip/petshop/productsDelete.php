<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'pet shop';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Запит для вибору наявної інформації
$select_query = "SELECT * FROM product";
$result = $conn->query($select_query);

if ($result->num_rows > 0) {
    // Вивід таблиці з продуктами
    echo '<table border="1">';
    echo '<tr><th>ID</th><th>Назва продукту</th><th>Кількість</th><th>Ціна</th><th>Категорія</th></tr>';

    while ($row = $result->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . $row['product_id'] . '</td>';
        echo '<td>' . $row['product_name'] . '</td>';
        echo '<td>' . $row['Amount'] . '</td>';
        echo '<td>' . $row['price'] . '</td>';
        echo '<td>' . $row['category'] . '</td>';
        echo '</tr>';
    }

    echo '</table>';
} else {
    echo "Немає даних для відображення.";
}

// Обробка відправленої форми для видалення
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $product_id = $_POST['product_id'];

    // SQL-запит для видалення продукту
    $sql = "DELETE FROM product WHERE product_id='$product_id'";

    if ($conn->query($sql) === TRUE) {
        echo "Продукт успішно видалено!";
    } else {
        echo "Помилка видалення продукту: " . $conn->error;
    }
}

// Запит для вибору наявної інформації після видалення
$select_query = "SELECT * FROM product";
$result = $conn->query($select_query);

if ($result->num_rows > 0) {
    // Вивід форми для видалення
    echo '<form method="post" action="">';
    echo '<label for="product_id">Виберіть продукт для видалення:</label>';
    echo '<select name="product_id">';

    while ($row = $result->fetch_assoc()) {
        echo '<option value="' . $row['product_id'] . '">' . $row['product_name'] . '</option>';
    }

    echo '</select>';
    echo '<input type="submit" value="Видалити">';
    echo '</form>';
} else {
    echo "Немає даних для видалення.";
}

$conn->close();
?>
<br><br>

<ul>
    <li><a href="showProduct.php">Таблиця Product </a><br></li>
    <li><a href="index.html">На головну</a><br></li>
</ul>