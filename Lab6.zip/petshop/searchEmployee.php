<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'pet shop';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Обробка відправленої форми для пошуку працівника
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $search_term = $_POST['search_term'];

    // SQL-запит для пошуку працівників за ім'ям або прізвищем
    $sql = "SELECT * FROM employee WHERE Name LIKE '%$search_term%' OR Surname LIKE '%$search_term%'";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Вивід результатів пошуку працівників
        echo '<table border="1">';
        echo '<tr><th>ІД працівника</th><th>Ім\'я працівника</th><th>Прізвище працівника</th><th>Номер телефону</th></tr>';

        while ($row = $result->fetch_assoc()) {
            echo '<tr>';
            echo '<td>' . $row['employee_id'] . '</td>';
            echo '<td>' . $row['Name'] . '</td>';
            echo '<td>' . $row['Surname'] . '</td>';
            echo '<td>' . $row['phone number'] . '</td>';  // Corrected column name
            echo '</tr>';
        }

        echo '</table>';
    } else {
        echo "Немає результатів для відображення.";
    }
}

$conn->close();
?>

<form method="post" action="">
    <label for="search_term">Пошук за ім'ям або прізвищем:</label>
    <input type="text" name="search_term" required>
    <input type="submit" value="Пошук">
</form>
<br><br>

    <ul>
        <li><a href="showEmployee.php">Таблиця Employee </a><br></li>
        <li><a href="index.html">На головну</a><br></li>
    </ul>